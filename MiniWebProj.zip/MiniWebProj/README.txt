Step 1) Launch pythonscrap.py 
	
	note: Dont close the program let it run in background

Step 2) Open the MiniProjectin.html file


******  THE END  **********