import bs4
from bs4 import BeautifulSoup as bs
import requests
import json
import os
import time

while True:         #Loop to run code for every 10 minutes

    paths = (__file__).split("\\")
    curDir = "\\".join(paths[:-1])
    os.chdir(curDir)

    link = "https://www.flipkart.com/search?q=tv&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off"
    page = requests.get(link)
    soup = bs(page.content, 'html.parser')
    for data in range(1):
        name = soup.find("div",class_="_4rR01T")
        rating = soup.find("div", class_="_3LWZlK")
        specification = soup.find("div", class_="fMghEO")
        for each in specification:
            spec = each.find_all("li", class_="rgWa7D")
            for data in spec:
                print(data.text)
        price = soup.find("div", class_="_30jeq3 _1_WHN1")

    products, prices, ratings, apps = [], [], [], []
    opS, hd, sound, images = [], [], [], []

    for data in soup.findAll("a", class_="_1fQZEK"):
        image = data.find("img", attrs={'class':'_396cs4 _3exPp9'})
        names = data.find("div", attrs={'class':'_4rR01T'})
        price = data.find("div", attrs={'class':'_30jeq3 _1_WHN1'})
        rating = data.find("div", attrs={'class':'_3LWZlK'})
        specification = data.find("div", attrs={'class':'fMghEO'})
        for each in specification:
            col = each.find_all("li", attrs={'class':'rgWa7D'})
            app = col[0].text
            os_ = col[1].text
            hd_ = col[2].text
            sound_ = col[3].text
        
        products.append(names.text)
        prices.append(price.text)
        apps.append(app)
        opS.append(os_)
        hd.append(hd_)
        sound.append(sound_)
        if(rating):
            ratings.append(rating.text)
        else:
            ratings.append("NA")
        images.append(image['src'])

    prodDictLi = []
    for i in range(len(products)):
        prodDict = {}
        prodDict["name"] = products[i]
        prodDict["rating"] = ratings[i]
        prodDict["price"] = prices[i]
        prodDict["image"] = [images[i],images[i]]
        prodDictLi.append(prodDict)
    prodStr = json.dumps(prodDictLi)
    '''with open('MiniProjectin.js', 'r') as f:
        data1 = f.read()
        print(type(data1))
    with open('tempfile.txt', 'w') as f:
        f.write(data1)
    '''
    with open('tempfile.txt', 'r') as f:
        data = f.read()
    with open('MiniProjectin.js', 'w') as f:
        data2 = [{'name': 'Kishore', 'age': 22, 'origin': 'Pythoneer'},{'name': 'Prasanth', 'age': 18, 'origin': 'Pythonista'}]
        datastr = "let scrappedData = "+str(prodStr)+";\n"
        f.write(datastr)
    with open('MiniProjectin.js', 'a') as f:
        f.write(data)
    time.sleep(60)
