let scrappedData = [{"name": "Adsun 98.9 cm (39 inch) HD Ready LED Smart TV", "rating": "3.8", "price": "\u20b912,775", "image": ["https://rukminim1.flixcart.com/image/312/312/krntoy80/television/h/c/b/50aesl1-adsun-original-imag5ecwjrm6ufsn.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/krntoy80/television/h/c/b/50aesl1-adsun-original-imag5ecwjrm6ufsn.jpeg?q=70"]}, {"name": "Adsun Frameless 80 cm (32 inch) HD Ready LED Smart TV", "rating": "3.8", "price": "\u20b99,499", "image": ["https://rukminim1.flixcart.com/image/312/312/kzn17680/television/o/q/p/a-3210s-f-adsun-original-imagbhqzhafpzhyz.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kzn17680/television/o/q/p/a-3210s-f-adsun-original-imagbhqzhafpzhyz.jpeg?q=70"]}, {"name": "Xiaomi 5A 80 cm (32 inch) HD Ready LED Smart Android TV with Dolby Audio (2022 Model)", "rating": "4.2", "price": "\u20b915,499", "image": ["https://rukminim1.flixcart.com/image/312/312/l2ghgnk0/television/u/a/c/l32m7-5ain-mi-original-imagdsdwqf6bkmkz.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/l2ghgnk0/television/u/a/c/l32m7-5ain-mi-original-imagdsdwqf6bkmkz.jpeg?q=70"]}, {"name": "LG 108 cm (43 inch) Ultra HD (4K) LED Smart TV", "rating": "4.4", "price": "\u20b932,990", "image": ["https://rukminim1.flixcart.com/image/312/312/kqse07k0/television/j/r/b/43up7500ptz-43up7500ptz-lg-original-imag4q3zcqt5n3yv.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kqse07k0/television/j/r/b/43up7500ptz-43up7500ptz-lg-original-imag4q3zcqt5n3yv.jpeg?q=70"]}, {"name": "realme 80 cm (32 inch) HD Ready LED Smart Android TV", "rating": "4.3", "price": "\u20b914,999", "image": ["https://rukminim1.flixcart.com/image/312/312/kae95e80/television/f/6/y/realme-tv-32-original-imafrz79pweqeafh.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kae95e80/television/f/6/y/realme-tv-32-original-imafrz79pweqeafh.jpeg?q=70"]}, {"name": "LG 80 cm (32 inch) HD Ready LED Smart TV", "rating": "4.4", "price": "\u20b917,499", "image": ["https://rukminim1.flixcart.com/image/312/312/kdyus280/television/g/d/q/lg-32lm565bpta-32lm565bpta-original-imafurgkdrjfggbw.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kdyus280/television/g/d/q/lg-32lm565bpta-32lm565bpta-original-imafurgkdrjfggbw.jpeg?q=70"]}, {"name": "OnePlus Y1 80 cm (32 inch) HD Ready LED Smart Android TV", "rating": "4.3", "price": "\u20b915,999", "image": ["https://rukminim1.flixcart.com/image/312/312/kqidx8w0/television/m/1/v/32ha0a00-oneplus-original-imag4gy8yezxdhen.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kqidx8w0/television/m/1/v/32ha0a00-oneplus-original-imag4gy8yezxdhen.jpeg?q=70"]}, {"name": "Croma 81.28 cm (32 inch) HD Ready LED TV", "rating": "4.2", "price": "\u20b98,490", "image": ["https://rukminim1.flixcart.com/image/312/312/ku1k4280/television/p/f/6/crel7369-croma-original-imag7969pxhrwp2k.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/ku1k4280/television/p/f/6/crel7369-croma-original-imag7969pxhrwp2k.jpeg?q=70"]}, {"name": "OnePlus Y1S 80 cm (32 inch) HD Ready LED Smart Android TV", "rating": "4.2", "price": "\u20b916,499", "image": ["https://rukminim1.flixcart.com/image/312/312/kzfvzww0/television/e/b/b/32hd2a00-32-y1s-oneplus-original-imagbgcewfqywgk7.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kzfvzww0/television/e/b/b/32hd2a00-32-y1s-oneplus-original-imagbgcewfqywgk7.jpeg?q=70"]}, {"name": "OnePlus Y1 108 cm (43 inch) Full HD LED Smart Android TV", "rating": "4.3", "price": "\u20b925,899", "image": ["https://rukminim1.flixcart.com/image/312/312/kqidx8w0/television/o/h/9/43fa0a00-oneplus-original-imag4gy9perzvrdv.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kqidx8w0/television/o/h/9/43fa0a00-oneplus-original-imag4gy9perzvrdv.jpeg?q=70"]}, {"name": "SAMSUNG Crystal 4K Pro 108 cm (43 inch) Ultra HD (4K) LED Smart TV with Voice Search", "rating": "4.4", "price": "\u20b934,990", "image": ["https://rukminim1.flixcart.com/image/312/312/ko1smfk0/television/1/r/d/ua43aue60aklxl-ua43aue60aklxl-samsung-original-imag2hg7b55y8xhs.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/ko1smfk0/television/1/r/d/ua43aue60aklxl-ua43aue60aklxl-samsung-original-imag2hg7b55y8xhs.jpeg?q=70"]}, {"name": "Croma 60.9 cm (24 inch) HD Ready LED TV", "rating": "4.2", "price": "\u20b96,990", "image": ["https://rukminim1.flixcart.com/image/312/312/ku79vgw0/television/w/y/q/crele3101sbt24-croma-original-imag7djy8zcvjghz.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/ku79vgw0/television/w/y/q/crele3101sbt24-croma-original-imag7djy8zcvjghz.jpeg?q=70"]}, {"name": "Mi 4A Horizon Edition 100 cm (40 inch) Full HD LED Smart Android TV", "rating": "4.3", "price": "\u20b921,990", "image": ["https://rukminim1.flixcart.com/image/312/312/kp4difk0/television/y/z/0/l40m6-ei-mi-original-imag3fbyhsdgxxke.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kp4difk0/television/y/z/0/l40m6-ei-mi-original-imag3fbyhsdgxxke.jpeg?q=70"]}, {"name": "Mi 5X 108 cm (43 inch) Ultra HD (4K) LED Smart Android TV with Dolby Atmos and Dolby Vision", "rating": "4.3", "price": "\u20b931,999", "image": ["https://rukminim1.flixcart.com/image/312/312/ksoz53k0/television/c/p/h/l43m6-es-mi-original-imag6774wykv4ps8.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/ksoz53k0/television/c/p/h/l43m6-es-mi-original-imag6774wykv4ps8.jpeg?q=70"]}, {"name": "SAMSUNG Crystal 4K 108 cm (43 inch) Ultra HD (4K) LED Smart TV", "rating": "4.3", "price": "\u20b933,990", "image": ["https://rukminim1.flixcart.com/image/312/312/ko1smfk0/television/1/r/d/ua43aue60aklxl-ua43aue60aklxl-samsung-original-imag2hg7b55y8xhs.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/ko1smfk0/television/1/r/d/ua43aue60aklxl-ua43aue60aklxl-samsung-original-imag2hg7b55y8xhs.jpeg?q=70"]}, {"name": "Croma 98 cm (39 inch) HD Ready LED TV", "rating": "3.8", "price": "\u20b912,990", "image": ["https://rukminim1.flixcart.com/image/312/312/kzygpzk0/television/1/l/h/crel040hbc024601-croma-original-imagbukzqjtxfzdc.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kzygpzk0/television/1/l/h/crel040hbc024601-croma-original-imagbukzqjtxfzdc.jpeg?q=70"]}, {"name": "Mi 4A PRO 80 cm (32 inch) HD Ready LED Smart Android TV", "rating": "4.4", "price": "\u20b916,499", "image": ["https://rukminim1.flixcart.com/image/312/312/kq6yefk0/television/n/w/v/l32m5-al-mi-original-imag4967mvqvpvgp.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kq6yefk0/television/n/w/v/l32m5-al-mi-original-imag4967mvqvpvgp.jpeg?q=70"]}, {"name": "Mi 4A Horizon Edition 80 cm (32 inch) HD Ready LED Smart Android TV", "rating": "4.3", "price": "\u20b916,499", "image": ["https://rukminim1.flixcart.com/image/312/312/kf5pzm80/television/f/h/e/mi-l32m6-ei-original-imafvzefsh27shv6.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kf5pzm80/television/f/h/e/mi-l32m6-ei-original-imafvzefsh27shv6.jpeg?q=70"]}, {"name": "Vu Premium 126 cm (50 inch) Ultra HD (4K) LED Smart Android TV", "rating": "4.4", "price": "\u20b931,999", "image": ["https://rukminim1.flixcart.com/image/312/312/kx6fwcw0/television/w/5/8/-original-imag9zvwz5ffv9ec.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kx6fwcw0/television/w/5/8/-original-imag9zvwz5ffv9ec.jpeg?q=70"]}, {"name": "Croma 80 cm (32 inch) HD Ready LED Smart Android TV", "rating": "4.1", "price": "\u20b912,990", "image": ["https://rukminim1.flixcart.com/image/312/312/l1nwnm80/television/2/i/r/crel032hof024601-croma-original-imagd69t6mysezaw.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/l1nwnm80/television/2/i/r/crel032hof024601-croma-original-imagd69t6mysezaw.jpeg?q=70"]}, {"name": "Vu Premium 108 cm (43 inch) Full HD LED Smart Android TV", "rating": "4.2", "price": "\u20b922,499", "image": ["https://rukminim1.flixcart.com/image/312/312/kynb6vk0/television/r/5/g/-original-imagatzzmayhsjzc.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kynb6vk0/television/r/5/g/-original-imagatzzmayhsjzc.jpeg?q=70"]}, {"name": "Vu Premium TV 80 cm (32 inch) HD Ready LED Smart TV with Bezel-Less Frame", "rating": "4.2", "price": "\u20b912,499", "image": ["https://rukminim1.flixcart.com/image/312/312/kylvr0w0/television/k/l/8/-original-imagasrugg4dygfx.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/kylvr0w0/television/k/l/8/-original-imagasrugg4dygfx.jpeg?q=70"]}, {"name": "Xiaomi 5A 108 cm (43 inch) Full HD LED Smart Android TV with Dolby Audio (2022 Model)", "rating": "4.2", "price": "\u20b925,999", "image": ["https://rukminim1.flixcart.com/image/312/312/l2f20sw0/television/k/s/l/l43m7-eain-mi-original-imagdrtndgnrymr9.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/l2f20sw0/television/k/s/l/l43m7-eain-mi-original-imagdrtndgnrymr9.jpeg?q=70"]}, {"name": "Dyanora 60 cm (24 inch) HD Ready LED Smart TV", "rating": "4.2", "price": "\u20b98,499", "image": ["https://rukminim1.flixcart.com/image/312/312/ktvucnk0/television/f/x/w/dy-ld24h0s-dy-ld24h0s-dyanora-original-imag74htez8jcnyq.jpeg?q=70", "https://rukminim1.flixcart.com/image/312/312/ktvucnk0/television/f/x/w/dy-ld24h0s-dy-ld24h0s-dyanora-original-imag74htez8jcnyq.jpeg?q=70"]}];



let sectionPaths = []
let sectionPathsEl = document.getElementById("sectionPaths");
let filtersContainerEl = document.getElementById("filtersContainer");
let productCardEl = document.getElementById("productCard");
let productContainerEl = document.getElementById("productContainer");
let carouselExampleSlidesOnlyEl = document.getElementById("carouselExampleSlidesOnly");



let scrappedData1 = [{
        "landingPageUrl": "tshirts/united-colors-of-benetton/united-colors-of-benetton-men-burgundy-round-neck-t-shirt/17565718/buy",
        "loyaltyPointsEnabled": false,
        "adId": "",
        "isPLA": false,
        "productId": 17565718,
        "product": "United Colors of Benetton Men Burgundy Round Neck T-shirt",
        "productName": "United Colors of Benetton Men Burgundy Round Neck T-shirt",
        "rating": 4.590909004211426,
        "ratingCount": 44,
        "isFastFashion": true,
        "futureDiscountedPrice": 0,
        "futureDiscountStartDate": "",
        "discount": 294,
        "brand": "United Colors of Benetton",
        "searchImage": "http://assets.myntassets.com/assets/images/17565718/2022/4/11/7074f9e5-78b8-4fb5-a66c-4eb7203766111649675233992-United-Colors-of-Benetton-Men-Burgundy-Round-Neck-T-shirt-44-1.jpg",
        "effectiveDiscountPercentageAfterTax": 0,
        "effectiveDiscountAmountAfterTax": 0,
        "buyButtonWinnerSkuId": 53831456,
        "buyButtonWinnerSellerPartnerId": 4036,
        "relatedStylesCount": 0,
        "relatedStylesType": "",
        "productVideos": [],
        "inventoryInfo": [{
                "skuId": 53831448,
                "label": "S",
                "inventory": 135,
                "available": true
            },
            {
                "skuId": 53831450,
                "label": "M",
                "inventory": 217,
                "available": true
            },
            {
                "skuId": 53831454,
                "label": "L",
                "inventory": 150,
                "available": true
            },
            {
                "skuId": 53831456,
                "label": "XL",
                "inventory": 1,
                "available": true
            }
        ],
        "sizes": "S,M,L,XL",
        "images": [{
                "view": "default",
                "src": "http://assets.myntassets.com/assets/images/17565718/2022/4/11/7074f9e5-78b8-4fb5-a66c-4eb7203766111649675233992-United-Colors-of-Benetton-Men-Burgundy-Round-Neck-T-shirt-44-1.jpg"
            },
            {
                "view": "size_representation",
                "src": ""
            },
            {
                "view": "back",
                "src": "http://assets.myntassets.com/assets/images/17565718/2022/4/11/cba531ca-5a18-44ab-980d-c28744e353bc1649675233951-United-Colors-of-Benetton-Men-Burgundy-Round-Neck-T-shirt-44-3.jpg"
            },
            {
                "view": "front",
                "src": "http://assets.myntassets.com/assets/images/17565718/2022/4/11/ddcb343e-6268-46e6-8331-9411ef339fdb1649675233972-United-Colors-of-Benetton-Men-Burgundy-Round-Neck-T-shirt-44-2.jpg"
            },
            {
                "view": "right",
                "src": "http://assets.myntassets.com/assets/images/17565718/2022/4/11/07876dcc-d13e-416c-9535-93a81693f8ee1649675233932-United-Colors-of-Benetton-Men-Burgundy-Round-Neck-T-shirt-44-4.jpg"
            },
            {
                "view": "search",
                "src": "http://assets.myntassets.com/assets/images/17565718/2022/4/11/7074f9e5-78b8-4fb5-a66c-4eb7203766111649675233992-United-Colors-of-Benetton-Men-Burgundy-Round-Neck-T-shirt-44-1.jpg"
            },
            {
                "view": "top",
                "src": "http://assets.myntassets.com/assets/images/17565718/2022/4/11/7b68be25-ca75-48b0-af9f-eb5e4ed241141649675233891-United-Colors-of-Benetton-Men-Burgundy-Round-Neck-T-shirt-44-6.jpg"
            },
            {
                "view": "left",
                "src": "http://assets.myntassets.com/assets/images/17565718/2022/4/11/722508e1-0bfb-4f15-aeb4-c7473576ce741649675233911-United-Colors-of-Benetton-Men-Burgundy-Round-Neck-T-shirt-44-5.jpg"
            }
        ],
        "gender": "Men",
        "primaryColour": "Burgundy",
        "discountLabel": "Flat_Search_Percent",
        "discountDisplayLabel": "(35% OFF)",
        "additionalInfo": "Men  Round Neck T-shirt",
        "category": "Tshirts",
        "mrp": 839,
        "price": 545,
        "advanceOrderTag": "",
        "colorVariantAvailable": false,
        "productimagetag": "",
        "listViews": 0,
        "discountType": "1",
        "tdBxGyText": "",
        "catalogDate": "1649289600000",
        "season": "Summer",
        "year": "2022",
        "isPersonalised": false,
        "eorsPicksTag": "",
        "personalizedCoupon": "",
        "personalizedCouponValue": 0,
        "productMeta": "",
        "systemAttributes": [{
                "attribute": "MP_High_Depth_Intent",
                "value": "High_Depth_Intent"
            },
            {
                "attribute": "MP_High_Depth",
                "value": "High_Depth"
            },
            {
                "attribute": "SA_XT_Best_Price",
                "value": "Price may go up"
            },
            {
                "attribute": "SA_XT_New_Season",
                "value": "NEW SEASON"
            }
        ],
        "attributeTagsPriorityList": [],
        "preferredDeliveryTag": "",
        "deliveryPromise": ""
    },
    {
        "landingPageUrl": "tshirts/roadster/roadster-men-navy-blue--olive-green-striped-polo-collar-pure-cotton-t-shirt/8829449/buy",
        "loyaltyPointsEnabled": false,
        "adId": "",
        "isPLA": false,
        "productId": 8829449,
        "product": "Roadster Men Navy Blue  Olive Green Striped Polo Collar Pure Cotton T-shirt",
        "productName": "Roadster Men Navy Blue  Olive Green Striped Polo Collar Pure Cotton T-shirt",
        "rating": 4.146266937255859,
        "ratingCount": 1969,
        "isFastFashion": true,
        "futureDiscountedPrice": 0,
        "futureDiscountStartDate": "",
        "discount": 650,
        "brand": "Roadster",
        "searchImage": "http://assets.myntassets.com/assets/images/8829449/2019/3/27/53f054a2-9e25-4323-b7cb-3dd75a8a935a1553680531988-Roadster-Men-Navy-Blue-Striped-Polo-Collar-T-shirt-295155368-1.jpg",
        "effectiveDiscountPercentageAfterTax": 0,
        "effectiveDiscountAmountAfterTax": 0,
        "buyButtonWinnerSkuId": 33480587,
        "buyButtonWinnerSellerPartnerId": 4118,
        "relatedStylesCount": 0,
        "relatedStylesType": "",
        "productVideos": [],
        "inventoryInfo": [{
                "skuId": 48001642,
                "label": "XS",
                "inventory": 0,
                "available": false
            },
            {
                "skuId": 33480587,
                "label": "S",
                "inventory": 519,
                "available": true
            },
            {
                "skuId": 33480589,
                "label": "M",
                "inventory": 886,
                "available": true
            },
            {
                "skuId": 33480591,
                "label": "L",
                "inventory": 443,
                "available": true
            },
            {
                "skuId": 33480592,
                "label": "XL",
                "inventory": 145,
                "available": true
            },
            {
                "skuId": 44915512,
                "label": "XXL",
                "inventory": 0,
                "available": false
            },
            {
                "skuId": 44915774,
                "label": "3XL",
                "inventory": 0,
                "available": false
            },
            {
                "skuId": 48009376,
                "label": "4XL",
                "inventory": 0,
                "available": false
            }
        ],
        "sizes": "S,M,L,XL",
        "images": [{
                "view": "default",
                "src": "http://assets.myntassets.com/assets/images/8829449/2019/3/27/53f054a2-9e25-4323-b7cb-3dd75a8a935a1553680531988-Roadster-Men-Navy-Blue-Striped-Polo-Collar-T-shirt-295155368-1.jpg"
            },
            {
                "view": "left",
                "src": "http://assets.myntassets.com/assets/images/8829449/2019/3/27/522bf308-1df1-4423-86f9-e032ce2c82461553680531923-Roadster-Men-Navy-Blue-Striped-Polo-Collar-T-shirt-295155368-5.jpg"
            },
            {
                "view": "size_representation",
                "src": ""
            },
            {
                "view": "back",
                "src": "http://assets.myntassets.com/assets/images/8829449/2019/3/27/72a8a1bf-a436-43eb-becb-65bc7f90d5ef1553680531957-Roadster-Men-Navy-Blue-Striped-Polo-Collar-T-shirt-295155368-3.jpg"
            },
            {
                "view": "right",
                "src": "http://assets.myntassets.com/assets/images/8829449/2019/3/27/1e019619-2b4b-45a4-a918-ce5d80f6352b1553680531938-Roadster-Men-Navy-Blue-Striped-Polo-Collar-T-shirt-295155368-4.jpg"
            },
            {
                "view": "front",
                "src": "http://assets.myntassets.com/assets/images/8829449/2019/3/27/3db99b4f-b8d0-488c-821a-e570c0408cdd1553680531973-Roadster-Men-Navy-Blue-Striped-Polo-Collar-T-shirt-295155368-2.jpg"
            },
            {
                "view": "search",
                "src": "http://assets.myntassets.com/assets/images/8829449/2019/3/27/53f054a2-9e25-4323-b7cb-3dd75a8a935a1553680531988-Roadster-Men-Navy-Blue-Striped-Polo-Collar-T-shirt-295155368-1.jpg"
            }
        ],
        "gender": "Men",
        "primaryColour": "Navy Blue",
        "discountLabel": "Flat_Search_Percent",
        "discountDisplayLabel": "(50% OFF)",
        "additionalInfo": "Striped Polo Collar Pure Cotton T-shirt",
        "category": "Tshirts",
        "mrp": 1299,
        "price": 649,
        "advanceOrderTag": "",
        "colorVariantAvailable": false,
        "productimagetag": "",
        "listViews": 0,
        "discountType": "1",
        "tdBxGyText": "",
        "catalogDate": "1553126400000",
        "season": "Spring",
        "year": "2019",
        "isPersonalised": false,
        "eorsPicksTag": "",
        "personalizedCoupon": "",
        "personalizedCouponValue": 0,
        "productMeta": "",
        "systemAttributes": [{
            "attribute": "SA_XT_PICWORTHY",
            "value": "PIC-WORTHY"
        }],
        "attributeTagsPriorityList": [],
        "preferredDeliveryTag": "",
        "deliveryPromise": ""
    },
    {
        "landingPageUrl": "tshirts/us-polo-assn/us-polo-assn-men-navy-blue-striped--embroidered-polo-collar-pure-cotton-t-shirt/11359732/buy",
        "loyaltyPointsEnabled": false,
        "adId": "",
        "isPLA": false,
        "productId": 11359732,
        "product": "U.S. Polo Assn. Men Navy Blue Striped  Embroidered Polo Collar Pure Cotton T-shirt",
        "productName": "U.S. Polo Assn. Men Navy Blue Striped  Embroidered Polo Collar Pure Cotton T-shirt",
        "rating": 4.465838432312012,
        "ratingCount": 161,
        "isFastFashion": true,
        "futureDiscountedPrice": 0,
        "futureDiscountStartDate": "",
        "discount": 665,
        "brand": "U.S. Polo Assn.",
        "searchImage": "http://assets.myntassets.com/assets/images/11359732/2020/6/22/1eee516d-88e0-4e11-be74-38314b78b7e51592819082066ShirtsUSPoloAssnMenShirtsUSPoloAssnMenShirtsUSPoloAssnMenShi1.jpg",
        "effectiveDiscountPercentageAfterTax": 0,
        "effectiveDiscountAmountAfterTax": 0,
        "buyButtonWinnerSkuId": 39387982,
        "buyButtonWinnerSellerPartnerId": 4036,
        "relatedStylesCount": 0,
        "relatedStylesType": "",
        "productVideos": [],
        "inventoryInfo": [{
                "skuId": 39387982,
                "label": "S",
                "inventory": 11,
                "available": true
            },
            {
                "skuId": 39387980,
                "label": "M",
                "inventory": 104,
                "available": true
            },
            {
                "skuId": 39387978,
                "label": "L",
                "inventory": 83,
                "available": true
            },
            {
                "skuId": 39387984,
                "label": "XL",
                "inventory": 101,
                "available": true
            },
            {
                "skuId": 39387986,
                "label": "XXL",
                "inventory": 28,
                "available": true
            }
        ],
        "sizes": "S,M,L,XL,XXL",
        "images": [{
                "view": "default",
                "src": "http://assets.myntassets.com/assets/images/11359732/2020/6/22/1eee516d-88e0-4e11-be74-38314b78b7e51592819082066ShirtsUSPoloAssnMenShirtsUSPoloAssnMenShirtsUSPoloAssnMenShi1.jpg"
            },
            {
                "view": "search",
                "src": "http://assets.myntassets.com/assets/images/11359732/2020/6/22/1eee516d-88e0-4e11-be74-38314b78b7e51592819082066ShirtsUSPoloAssnMenShirtsUSPoloAssnMenShirtsUSPoloAssnMenShi1.jpg"
            },
            {
                "view": "left",
                "src": "http://assets.myntassets.com/assets/images/11359732/2020/6/22/077f97e2-792a-4ca1-81d5-21a197d467c51592819082321ShirtsUSPoloAssnMenShirtsUSPoloAssnMenShirtsUSPoloAssnMenShi5.jpg"
            },
            {
                "view": "size_representation",
                "src": ""
            },
            {
                "view": "back",
                "src": "http://assets.myntassets.com/assets/images/11359732/2020/6/22/e9120a77-de71-43e1-93e6-08862ea533c01592819082194ShirtsUSPoloAssnMenShirtsUSPoloAssnMenShirtsUSPoloAssnMenShi3.jpg"
            },
            {
                "view": "front",
                "src": "http://assets.myntassets.com/assets/images/11359732/2020/6/22/95517d15-25d3-473a-9a9f-33cd6d8362b81592819082130ShirtsUSPoloAssnMenShirtsUSPoloAssnMenShirtsUSPoloAssnMenShi2.jpg"
            },
            {
                "view": "right",
                "src": "http://assets.myntassets.com/assets/images/11359732/2020/6/22/e36651de-9177-4a66-a066-74fa34dd1f691592819082255ShirtsUSPoloAssnMenShirtsUSPoloAssnMenShirtsUSPoloAssnMenShi4.jpg"
            }
        ],
        "gender": "Men",
        "primaryColour": "Navy Blue",
        "discountLabel": "Flat_Search_Percent",
        "discountDisplayLabel": "(35% OFF)",
        "additionalInfo": "Striped Polo Collar Pure Cotton T-shirt",
        "category": "Tshirts",
        "mrp": 1899,
        "price": 1234,
        "advanceOrderTag": "",
        "colorVariantAvailable": false,
        "productimagetag": "",
        "listViews": 0,
        "discountType": "1",
        "tdBxGyText": "",
        "catalogDate": "1592438400000",
        "season": "Summer",
        "year": "2022",
        "isPersonalised": false,
        "eorsPicksTag": "",
        "personalizedCoupon": "",
        "personalizedCouponValue": 0,
        "productMeta": "",
        "systemAttributes": [{
                "attribute": "MP_High_Depth_Intent",
                "value": "High_Depth_Intent"
            },
            {
                "attribute": "MP_High_Depth",
                "value": "High_Depth"
            },
            {
                "attribute": "SA_XT_Best_Price",
                "value": "Price may go up"
            }
        ],
        "attributeTagsPriorityList": [],
        "preferredDeliveryTag": "",
        "deliveryPromise": ""
    },
    {
        "landingPageUrl": "tshirts/levis/levis-men-black--red-colourblocked-polo-collar-slim-fit--casual-t-shirt/16343412/buy",
        "loyaltyPointsEnabled": false,
        "adId": "",
        "isPLA": false,
        "productId": 16343412,
        "product": "Levis Men Black & Red Colourblocked Polo Collar Slim Fit  Casual T-shirt",
        "productName": "Levis Men Black & Red Colourblocked Polo Collar Slim Fit  Casual T-shirt",
        "rating": 4.283019065856934,
        "ratingCount": 53,
        "isFastFashion": true,
        "futureDiscountedPrice": 0,
        "futureDiscountStartDate": "",
        "discount": 525,
        "brand": "Levis",
        "searchImage": "http://assets.myntassets.com/assets/images/16343412/2022/4/1/14ae91cc-1d8e-4721-8a8e-2b8e1e0fd5451648806274539-Levis-Men-Tshirts-1911648806273964-1.jpg",
        "effectiveDiscountPercentageAfterTax": 0,
        "effectiveDiscountAmountAfterTax": 0,
        "buyButtonWinnerSkuId": 51561616,
        "buyButtonWinnerSellerPartnerId": 4215,
        "relatedStylesCount": 0,
        "relatedStylesType": "",
        "productVideos": [],
        "inventoryInfo": [{
                "skuId": 51561620,
                "label": "S",
                "inventory": 112,
                "available": true
            },
            {
                "skuId": 51561618,
                "label": "M",
                "inventory": 329,
                "available": true
            },
            {
                "skuId": 51561616,
                "label": "L",
                "inventory": 263,
                "available": true
            },
            {
                "skuId": 51561622,
                "label": "XL",
                "inventory": 136,
                "available": true
            },
            {
                "skuId": 51561624,
                "label": "XXL",
                "inventory": 59,
                "available": true
            }
        ],
        "sizes": "S,M,L,XL,XXL",
        "images": [{
                "view": "default",
                "src": "http://assets.myntassets.com/assets/images/16343412/2022/4/1/14ae91cc-1d8e-4721-8a8e-2b8e1e0fd5451648806274539-Levis-Men-Tshirts-1911648806273964-1.jpg"
            },
            {
                "view": "front",
                "src": "http://assets.myntassets.com/assets/images/16343412/2022/4/1/9c79d76d-cef9-41c5-87ad-57d97e139adb1648806274530-Levis-Men-Tshirts-1911648806273964-2.jpg"
            },
            {
                "view": "right",
                "src": "http://assets.myntassets.com/assets/images/16343412/2022/4/1/8d5fbcee-e23a-471a-8217-99fee52007f11648806274512-Levis-Men-Tshirts-1911648806273964-4.jpg"
            },
            {
                "view": "search",
                "src": "http://assets.myntassets.com/assets/images/16343412/2022/4/1/14ae91cc-1d8e-4721-8a8e-2b8e1e0fd5451648806274539-Levis-Men-Tshirts-1911648806273964-1.jpg"
            },
            {
                "view": "top",
                "src": "http://assets.myntassets.com/assets/images/16343412/2022/4/1/ce508dd7-41e4-4c26-af05-7d118a9c94971648806274495-Levis-Men-Tshirts-1911648806273964-6.jpg"
            },
            {
                "view": "left",
                "src": "http://assets.myntassets.com/assets/images/16343412/2022/4/1/00edb302-99bc-4007-a591-ef5344f439fc1648806274503-Levis-Men-Tshirts-1911648806273964-5.jpg"
            },
            {
                "view": "size_representation",
                "src": ""
            },
            {
                "view": "back",
                "src": "http://assets.myntassets.com/assets/images/16343412/2022/4/1/944d1544-e667-4fae-b479-1bfb6dd70b671648806274521-Levis-Men-Tshirts-1911648806273964-3.jpg"
            }
        ],
        "gender": "Men",
        "primaryColour": "Black",
        "discountLabel": "Flat_Search_Percent",
        "discountDisplayLabel": "(35% OFF)",
        "additionalInfo": "Men Colourblocked Polo Collar Slim Fit T-shirt",
        "category": "Tshirts",
        "mrp": 1499,
        "price": 974,
        "advanceOrderTag": "",
        "colorVariantAvailable": false,
        "productimagetag": "",
        "listViews": 0,
        "discountType": "1",
        "tdBxGyText": "",
        "catalogDate": "1649289600000",
        "season": "Summer",
        "year": "2022",
        "isPersonalised": false,
        "eorsPicksTag": "",
        "personalizedCoupon": "",
        "personalizedCouponValue": 0,
        "productMeta": "",
        "systemAttributes": [{
                "attribute": "SA_XT_New_Season",
                "value": "NEW SEASON"
            },
            {
                "attribute": "SA_XT_Best_Price",
                "value": "Price may go up"
            },
            {
                "attribute": "MP_High_Depth_Intent",
                "value": "High_Depth_Intent"
            },
            {
                "attribute": "MP_High_Depth",
                "value": "High_Depth"
            }
        ],
        "attributeTagsPriorityList": [],
        "preferredDeliveryTag": "",
        "deliveryPromise": ""
    },
    {
        "landingPageUrl": "tshirts/hm/hm-men-white-solid-cotton-pure-cotton-t-shirt-regular-fit/11468714/buy",
        "loyaltyPointsEnabled": false,
        "adId": "",
        "isPLA": false,
        "productId": 11468714,
        "product": "HM Men White Solid Cotton Pure Cotton T-shirt Regular Fit",
        "productName": "HM Men White Solid Cotton Pure Cotton T-shirt Regular Fit",
        "rating": 4.186807632446289,
        "ratingCount": 5776,
        "isFastFashion": true,
        "futureDiscountedPrice": 0,
        "futureDiscountStartDate": "",
        "discount": 0,
        "brand": "H&M",
        "searchImage": "http://assets.myntassets.com/assets/images/11468714/2022/2/7/cbdd604f-1341-47a9-92c6-2fe6078e89821644231911509-HM-Men-White-Solid-Cotton-Pure-Cotton-T-shirt-Regular-Fit-42-1.jpg",
        "effectiveDiscountPercentageAfterTax": 0,
        "effectiveDiscountAmountAfterTax": 0,
        "buyButtonWinnerSkuId": 39851000,
        "buyButtonWinnerSellerPartnerId": 6771,
        "relatedStylesCount": 0,
        "relatedStylesType": "",
        "productVideos": [],
        "inventoryInfo": [{
                "skuId": 39850996,
                "label": "XS",
                "inventory": 108,
                "available": true
            },
            {
                "skuId": 39850998,
                "label": "S",
                "inventory": 460,
                "available": true
            },
            {
                "skuId": 39851000,
                "label": "M",
                "inventory": 1161,
                "available": true
            },
            {
                "skuId": 39851002,
                "label": "L",
                "inventory": 885,
                "available": true
            },
            {
                "skuId": 39851004,
                "label": "XL",
                "inventory": 470,
                "available": true
            },
            {
                "skuId": 39851006,
                "label": "XXL",
                "inventory": 379,
                "available": true
            }
        ],
        "sizes": "XS,S,M,L,XL,XXL",
        "images": [{
                "view": "default",
                "src": "http://assets.myntassets.com/assets/images/11468714/2022/2/7/cbdd604f-1341-47a9-92c6-2fe6078e89821644231911509-HM-Men-White-Solid-Cotton-Pure-Cotton-T-shirt-Regular-Fit-42-1.jpg"
            },
            {
                "view": "bottom",
                "src": "http://assets.myntassets.com/assets/images/11468714/2022/3/9/73fcfc97-8f5d-4317-a3e8-1288529517291646815730668-HM-Men-White-Solid-Cotton-Pure-Cotton-T-shirt-Regular-Fit-13-7.jpg"
            },
            {
                "view": "right",
                "src": "http://assets.myntassets.com/assets/images/11468714/2022/2/7/65e45f63-56e0-4592-a1f4-81a94bea38bd1644231911471-HM-Men-White-Solid-Cotton-Pure-Cotton-T-shirt-Regular-Fit-42-4.jpg"
            },
            {
                "view": "front",
                "src": "http://assets.myntassets.com/assets/images/11468714/2022/2/7/f686e4a6-c0fa-4829-a755-47f9f5ab5d211644231911497-HM-Men-White-Solid-Cotton-Pure-Cotton-T-shirt-Regular-Fit-42-2.jpg"
            },
            {
                "view": "search",
                "src": "http://assets.myntassets.com/assets/images/11468714/2022/2/7/cbdd604f-1341-47a9-92c6-2fe6078e89821644231911509-HM-Men-White-Solid-Cotton-Pure-Cotton-T-shirt-Regular-Fit-42-1.jpg"
            },
            {
                "view": "top",
                "src": "http://assets.myntassets.com/assets/images/11468714/2022/3/4/eae8fd3a-2277-49ed-abf9-d90b20b16b211646379568288-HM-Men-White-Solid-Cotton-Pure-Cotton-T-shirt-Regular-Fit-32-6.jpg"
            },
            {
                "view": "left",
                "src": "http://assets.myntassets.com/assets/images/11468714/2022/3/2/aefd3211-7f20-4d01-bcfa-fd0cd02d3b111646219399223-HM-Men-White-Solid-Cotton-Pure-Cotton-T-shirt-Regular-Fit-32-5.jpg"
            },
            {
                "view": "size_representation",
                "src": ""
            },
            {
                "view": "back",
                "src": "http://assets.myntassets.com/assets/images/11468714/2022/2/7/feb2ba4f-6230-4047-bb34-acf91dbc938c1644231911484-HM-Men-White-Solid-Cotton-Pure-Cotton-T-shirt-Regular-Fit-42-3.jpg"
            }
        ],
        "gender": "Men",
        "primaryColour": "White",
        "discountLabel": "Flat_Search_Percent",
        "discountDisplayLabel": "",
        "additionalInfo": "Cotton Pure Cotton T-shirt Regular Fit",
        "category": "Tshirts",
        "mrp": 399,
        "price": 399,
        "advanceOrderTag": "",
        "colorVariantAvailable": false,
        "productimagetag": "",
        "listViews": 0,
        "discountType": "1",
        "tdBxGyText": "",
        "catalogDate": "1580947200000",
        "season": "Winter",
        "year": "2020",
        "isPersonalised": false,
        "eorsPicksTag": "",
        "personalizedCoupon": "",
        "personalizedCouponValue": 0,
        "productMeta": "",
        "systemAttributes": [{
            "attribute": "SA_XT_PICWORTHY",
            "value": "PIC-WORTHY"
        }],
        "attributeTagsPriorityList": [],
        "preferredDeliveryTag": "",
        "deliveryPromise": ""
    },
    {
        "landingPageUrl": "tshirts/roadster/roadster-men-black-self-design-henley-neck-t-shirt/12120706/buy",
        "loyaltyPointsEnabled": false,
        "adId": "",
        "isPLA": false,
        "productId": 12120706,
        "product": "Roadster Men Black Self Design Henley Neck T-shirt",
        "productName": "Roadster Men Black Self Design Henley Neck T-shirt",
        "rating": 4.195652008056641,
        "ratingCount": 92,
        "isFastFashion": true,
        "futureDiscountedPrice": 0,
        "futureDiscountStartDate": "",
        "discount": 540,
        "brand": "Roadster",
        "searchImage": "http://assets.myntassets.com/assets/images/12120706/2020/11/19/11ec19a6-3470-404b-a085-8b2ecb45b8ba1605788365143-Roadster-Men-Tshirts-6651605788363487-1.jpg",
        "effectiveDiscountPercentageAfterTax": 0,
        "effectiveDiscountAmountAfterTax": 0,
        "buyButtonWinnerSkuId": 42216388,
        "buyButtonWinnerSellerPartnerId": 4118,
        "relatedStylesCount": 0,
        "relatedStylesType": "",
        "productVideos": [],
        "inventoryInfo": [{
                "skuId": 48214932,
                "label": "XS",
                "inventory": 0,
                "available": false
            },
            {
                "skuId": 42216388,
                "label": "S",
                "inventory": 14,
                "available": true
            },
            {
                "skuId": 42216390,
                "label": "M",
                "inventory": 77,
                "available": true
            },
            {
                "skuId": 42216392,
                "label": "L",
                "inventory": 119,
                "available": true
            },
            {
                "skuId": 42216394,
                "label": "XL",
                "inventory": 109,
                "available": true
            }
        ],
        "sizes": "S,M,L,XL",
        "images": [{
                "view": "default",
                "src": "http://assets.myntassets.com/assets/images/12120706/2020/11/19/11ec19a6-3470-404b-a085-8b2ecb45b8ba1605788365143-Roadster-Men-Tshirts-6651605788363487-1.jpg"
            },
            {
                "view": "front",
                "src": "http://assets.myntassets.com/assets/images/12120706/2020/11/19/7901b741-7a61-4bae-8136-f031ecce06c51605788365099-Roadster-Men-Tshirts-6651605788363487-2.jpg"
            },
            {
                "view": "search",
                "src": "http://assets.myntassets.com/assets/images/12120706/2020/11/19/11ec19a6-3470-404b-a085-8b2ecb45b8ba1605788365143-Roadster-Men-Tshirts-6651605788363487-1.jpg"
            },
            {
                "view": "left",
                "src": "http://assets.myntassets.com/assets/images/12120706/2020/11/19/d7b1ab82-ddcb-4ad5-a672-abc541362d371605788364949-Roadster-Men-Tshirts-6651605788363487-5.jpg"
            },
            {
                "view": "size_representation",
                "src": ""
            },
            {
                "view": "back",
                "src": "http://assets.myntassets.com/assets/images/12120706/2020/11/19/d9acb946-5df9-4f76-8c34-2464c33ed3461605788365051-Roadster-Men-Tshirts-6651605788363487-3.jpg"
            },
            {
                "view": "right",
                "src": "http://assets.myntassets.com/assets/images/12120706/2020/11/19/9a7c010e-eb4c-4fc9-87e7-26287408383c1605788365000-Roadster-Men-Tshirts-6651605788363487-4.jpg"
            }
        ],
        "gender": "Men",
        "primaryColour": "Black",
        "discountLabel": "Flat_Search_Percent",
        "discountDisplayLabel": "(60% OFF)",
        "additionalInfo": "Self Design Henley Neck T-shirt",
        "category": "Tshirts",
        "mrp": 899,
        "price": 359,
        "advanceOrderTag": "",
        "colorVariantAvailable": false,
        "productimagetag": "",
        "listViews": 0,
        "discountType": "1",
        "tdBxGyText": "",
        "catalogDate": "1605744000000",
        "season": "Fall",
        "year": "2020",
        "isPersonalised": false,
        "eorsPicksTag": "",
        "personalizedCoupon": "",
        "personalizedCouponValue": 0,
        "productMeta": "",
        "systemAttributes": [{
            "attribute": "SA_XT_Best_Price",
            "value": "Price may go up"
        }],
        "attributeTagsPriorityList": [],
        "preferredDeliveryTag": "",
        "deliveryPromise": ""
    },
    {
        "landingPageUrl": "tshirts/nautica/nautica-men-dark-blue-solid-polo-collar-t-shirt/11487342/buy",
        "loyaltyPointsEnabled": false,
        "adId": "",
        "isPLA": false,
        "productId": 11487342,
        "product": "Nautica Men Dark Blue Solid Polo Collar T-shirt",
        "productName": "Nautica Men Dark Blue Solid Polo Collar T-shirt",
        "rating": 4.252688407897949,
        "ratingCount": 186,
        "isFastFashion": true,
        "futureDiscountedPrice": 0,
        "futureDiscountStartDate": "",
        "discount": 1170,
        "brand": "Nautica",
        "searchImage": "http://assets.myntassets.com/assets/images/11487342/2020/6/17/e3958d19-7c4b-49ce-8a5c-e82ed6e6ef321592396334332-Nautica-Men-Tshirts-721592396332125-1.jpg",
        "effectiveDiscountPercentageAfterTax": 0,
        "effectiveDiscountAmountAfterTax": 0,
        "buyButtonWinnerSkuId": 39932174,
        "buyButtonWinnerSellerPartnerId": 4118,
        "relatedStylesCount": 0,
        "relatedStylesType": "",
        "productVideos": [],
        "inventoryInfo": [{
                "skuId": 39932172,
                "label": "S",
                "inventory": 270,
                "available": true
            },
            {
                "skuId": 39932174,
                "label": "M",
                "inventory": 422,
                "available": true
            },
            {
                "skuId": 39932176,
                "label": "L",
                "inventory": 370,
                "available": true
            },
            {
                "skuId": 39932178,
                "label": "XL",
                "inventory": 288,
                "available": true
            },
            {
                "skuId": 39932180,
                "label": "XXL",
                "inventory": 167,
                "available": true
            }
        ],
        "sizes": "S,M,L,XL,XXL",
        "images": [{
                "view": "default",
                "src": "http://assets.myntassets.com/assets/images/11487342/2020/6/17/e3958d19-7c4b-49ce-8a5c-e82ed6e6ef321592396334332-Nautica-Men-Tshirts-721592396332125-1.jpg"
            },
            {
                "view": "front",
                "src": "http://assets.myntassets.com/assets/images/11487342/2020/6/17/e7013674-209c-4905-997e-c52b62b0d5d01592396334277-Nautica-Men-Tshirts-721592396332125-2.jpg"
            },
            {
                "view": "search",
                "src": "http://assets.myntassets.com/assets/images/11487342/2020/6/17/e3958d19-7c4b-49ce-8a5c-e82ed6e6ef321592396334332-Nautica-Men-Tshirts-721592396332125-1.jpg"
            },
            {
                "view": "top",
                "src": "http://assets.myntassets.com/assets/images/11487342/2020/6/17/5c44d766-c728-4f62-8818-1cb124879d1c1592396334086-Nautica-Men-Tshirts-721592396332125-6.jpg"
            },
            {
                "view": "left",
                "src": "http://assets.myntassets.com/assets/images/11487342/2020/6/17/6c1f01ed-ed82-493c-92bd-3df9a35605741592396334139-Nautica-Men-Tshirts-721592396332125-5.jpg"
            },
            {
                "view": "size_representation",
                "src": ""
            },
            {
                "view": "back",
                "src": "http://assets.myntassets.com/assets/images/11487342/2020/6/17/9b4cb0a0-82a5-48bd-bf8f-e1a38bbb47f21592396334227-Nautica-Men-Tshirts-721592396332125-3.jpg"
            },
            {
                "view": "right",
                "src": "http://assets.myntassets.com/assets/images/11487342/2020/6/17/3bd2f853-ce02-4d79-b600-143ea8aee2d21592396334184-Nautica-Men-Tshirts-721592396332125-4.jpg"
            }
        ],
        "gender": "Men",
        "primaryColour": "Blue",
        "discountLabel": "Flat_Search_Percent",
        "discountDisplayLabel": "(45% OFF)",
        "additionalInfo": "Solid Polo Collar T-shirt",
        "category": "Tshirts",
        "mrp": 2599,
        "price": 1429,
        "advanceOrderTag": "",
        "colorVariantAvailable": false,
        "productimagetag": "",
        "listViews": 0,
        "discountType": "1",
        "tdBxGyText": "",
        "catalogDate": "1592438400000",
        "season": "Summer",
        "year": "2022",
        "isPersonalised": false,
        "eorsPicksTag": "",
        "personalizedCoupon": "",
        "personalizedCouponValue": 0,
        "productMeta": "",
        "systemAttributes": [{
                "attribute": "VTR_Available",
                "value": "Yes"
            },
            {
                "attribute": "MP_High_Depth_Intent",
                "value": "High_Depth_Intent"
            },
            {
                "attribute": "MP_High_Depth",
                "value": "High_Depth"
            },
            {
                "attribute": "Custom_Label2",
                "value": "SA_FD_Label2"
            },
            {
                "attribute": "SA_XT_PICWORTHY",
                "value": "PIC-WORTHY"
            },
            {
                "attribute": "SA_XT_Best_Price",
                "value": "Price may go up"
            }
        ],
        "attributeTagsPriorityList": [],
        "preferredDeliveryTag": "",
        "deliveryPromise": ""
    },
    {
        "landingPageUrl": "tshirts/roadster/roadster-men-maroon-typography-printed-cotton-t-shirt/2308267/buy",
        "loyaltyPointsEnabled": false,
        "adId": "",
        "isPLA": false,
        "productId": 2308267,
        "product": "Roadster Men Maroon Typography Printed Cotton T-shirt",
        "productName": "Roadster Men Maroon Typography Printed Cotton T-shirt",
        "rating": 4.067904472351074,
        "ratingCount": 16641,
        "isFastFashion": true,
        "futureDiscountedPrice": 0,
        "futureDiscountStartDate": "",
        "discount": 350,
        "brand": "Roadster",
        "searchImage": "http://assets.myntassets.com/assets/images/2308267/2018/1/29/11517216335231-Roadster-Men-Maroon-Printed-Round-Neck-T-shirt-5591517216335098-1.jpg",
        "effectiveDiscountPercentageAfterTax": 0,
        "effectiveDiscountAmountAfterTax": 0,
        "buyButtonWinnerSkuId": 14952685,
        "buyButtonWinnerSellerPartnerId": 4118,
        "relatedStylesCount": 0,
        "relatedStylesType": "",
        "productVideos": [],
        "inventoryInfo": [{
                "skuId": 48001600,
                "label": "XS",
                "inventory": 0,
                "available": false
            },
            {
                "skuId": 14952684,
                "label": "S",
                "inventory": 1004,
                "available": true
            },
            {
                "skuId": 14952685,
                "label": "M",
                "inventory": 2495,
                "available": true
            },
            {
                "skuId": 14952686,
                "label": "L",
                "inventory": 1944,
                "available": true
            },
            {
                "skuId": 14952687,
                "label": "XL",
                "inventory": 852,
                "available": true
            },
            {
                "skuId": 44919086,
                "label": "XXL",
                "inventory": 0,
                "available": false
            },
            {
                "skuId": 44919028,
                "label": "3XL",
                "inventory": 0,
                "available": false
            },
            {
                "skuId": 48009330,
                "label": "4XL",
                "inventory": 0,
                "available": false
            }
        ],
        "sizes": "S,M,L,XL",
        "images": [{
                "view": "default",
                "src": "http://assets.myntassets.com/assets/images/2308267/2018/1/29/11517216335231-Roadster-Men-Maroon-Printed-Round-Neck-T-shirt-5591517216335098-1.jpg"
            },
            {
                "view": "back",
                "src": "http://assets.myntassets.com/assets/images/2308267/2018/1/29/11517216335188-Roadster-Men-Maroon-Printed-Round-Neck-T-shirt-5591517216335098-3.jpg"
            },
            {
                "view": "right",
                "src": "http://assets.myntassets.com/assets/images/2308267/2018/1/29/11517216335163-Roadster-Men-Maroon-Printed-Round-Neck-T-shirt-5591517216335098-4.jpg"
            },
            {
                "view": "front",
                "src": "http://assets.myntassets.com/assets/images/2308267/2018/1/29/11517216335209-Roadster-Men-Maroon-Printed-Round-Neck-T-shirt-5591517216335098-2.jpg"
            },
            {
                "view": "search",
                "src": "http://assets.myntassets.com/assets/images/2308267/2018/1/29/11517216335231-Roadster-Men-Maroon-Printed-Round-Neck-T-shirt-5591517216335098-1.jpg"
            },
            {
                "view": "left",
                "src": "http://assets.myntassets.com/assets/images/2308267/2018/1/29/11517216335135-Roadster-Men-Maroon-Printed-Round-Neck-T-shirt-5591517216335098-5.jpg"
            },
            {
                "view": "size_representation",
                "src": ""
            }
        ],
        "gender": "Men",
        "primaryColour": "Maroon",
        "discountLabel": "Flat_Search_Percent",
        "discountDisplayLabel": "(50% OFF)",
        "additionalInfo": "Typography Cotton T-shirt",
        "category": "Tshirts",
        "mrp": 699,
        "price": 349,
        "advanceOrderTag": "",
        "colorVariantAvailable": false,
        "productimagetag": "",
        "listViews": 0,
        "discountType": "1",
        "tdBxGyText": "",
        "catalogDate": "1516838400000",
        "season": "Summer",
        "year": "2019",
        "isPersonalised": false,
        "eorsPicksTag": "",
        "personalizedCoupon": "",
        "personalizedCouponValue": 0,
        "productMeta": "",
        "systemAttributes": [{
                "attribute": "SA_XT_BESTSELLER",
                "value": "BESTSELLER"
            },
            {
                "attribute": "SA_XT_PICWORTHY",
                "value": "PIC-WORTHY"
            }
        ],
        "attributeTagsPriorityList": [],
        "preferredDeliveryTag": "",
        "deliveryPromise": ""
    }
]
localStorage.setItem("myntraData", scrappedData);

function buildProductCard(item) {
    let productCardEl = document.createElement("div");
    productCardEl.classList.add("col-3", "product-card");
    productContainerEl.appendChild(productCardEl)

    //create Carousel
    let carouselElem = document.createElement("div");
    carouselElem.setAttribute("data-ride", "carousel");
    carouselElem.classList.add("carousel", "slide", "d-block");
    productCardEl.appendChild(carouselElem);

    let innerCarouselElem = document.createElement("div");
    innerCarouselElem.classList.add("carousel-inner");
    carouselElem.appendChild(innerCarouselElem);
    console.log(item);
    for (let picture of item["image"]) {
        let flag = true;
        let pictureContElem = document.createElement("div");
        pictureContElem.classList.add("carousel-item");
        innerCarouselElem.appendChild(pictureContElem);
        let imgElem = document.createElement("img");
        imgElem.classList.add("d-block", "w-100");
        imgElem.src = picture;
        pictureContElem.appendChild(imgElem);
        if (flag === true) {
            pictureContElem.classList.add("active");
            flag = false;
        }
    }
    //create Text container
    let textContainerElem = document.createElement("div");
    textContainerElem.classList.add("text-container");
    productCardEl.appendChild(textContainerElem);
    let divElem = document.createElement("div");
    textContainerElem.appendChild(divElem);
    let headingElem = document.createElement("h1");
    headingElem.classList.add("text-card-heading");
    headingElem.textContent = item["name"];
    divElem.appendChild(headingElem);
    let descriptionElem = document.createElement("p");
    descriptionElem.textContent = item["rating"];
    for (let i = 1; i <= 5; i++) {
        console.log(Math.round(parseFloat(item["rating"])));
        if (i <= Math.round(parseFloat(item["rating"]))) {
            let spEl = document.createElement("span");
            spEl.classList.add("fa", "fa-star", "checked");
            descriptionElem.appendChild(spEl);
        } else {
            let spEl = document.createElement("span");
            spEl.classList.add("fa", "fa-star");
            descriptionElem.appendChild(spEl);
        }
    }
    descriptionElem.classList.add("text-card-description");
    divElem.appendChild(descriptionElem);

    let divEl = document.createElement("div");
    divEl.classList.add("d-none", "text-center");
    textContainerElem.appendChild(divEl);
    let btnElem = document.createElement("button");
    btnElem.classList.add("btn", "btn-outline-dark", "btn-custom", "text-danger");
    btnElem.textContent = "WISHLIST";
    let sizedEl = document.createElement("p");
    sizedEl.classList.add("sized");
    sizedEl.textContent = item["name"] // item["sizes"];
    divEl.appendChild(btnElem);
    divEl.appendChild(sizedEl);

    let paraElem = document.createElement("p");
    let currentPrice = parseInt(item["price"].slice(1).replace(",", ""));
    paraElem.textContent = item["price"];
    paraElem.classList.add("price-tag");
    textContainerElem.appendChild(paraElem);
    let spanElem = document.createElement("span");
    let actualPrice = parseInt(item["price"].slice(1).replace(",", "")) + 5000;
    spanElem.textContent = " " + item["price"].slice(0, 1) + actualPrice;
    spanElem.classList.add("actual-price");
    paraElem.appendChild(spanElem);
    let spanEl = document.createElement("span");
    spanEl.textContent = "(" + Math.round(100 - currentPrice * 100 / actualPrice) + "% OFF)";
    spanEl.classList.add("discount-percent");
    paraElem.appendChild(spanEl);

    productCardEl.addEventListener("mouseenter", function(event) {
        console.log(event.target.childNodes[1].childNodes[0]);
        let textElem = event.target.childNodes[1].childNodes[0];
        textElem.classList.add("d-none");
        event.target.childNodes[1].childNodes[1].classList.remove("d-none");
        console.log(event.target.childNodes[1].childNodes[1]);
    });
    productCardEl.addEventListener("mouseleave", function(event) {
        event.target.childNodes[1].childNodes[0].classList.remove("d-none");
        event.target.childNodes[1].childNodes[1].classList.add("d-none");
        console.log(event.target.childNodes[1].childNodes[1]);
    });

}

let i = 0;
for (let each of scrappedData) {
    buildProductCard(each);
}

let filters = [{
        filter: "Categories",
        products: [{
                name: "Laptops",
                number: 100
            },
            {
                name: "TVs",
                number: 736
            },
            {
                name: "Mobiles",
                number: 7136
            },
            {
                name: "Tablets",
                number: 136
            }
        ]
    },
    {
        filter: "Brand",
        products: [{
                name: "Mi",
                number: 2688
            },
            {
                name: "OnePlus",
                number: 1732
            },
            {
                name: "Vu",
                number: 1613
            },
            {
                name: "Realme",
                number: 1360
            },
            {
                name: "Infinix",
                number: 1274
            },
            {
                name: "Kodak",
                number: 1253
            },
            {
                name: "Thompson",
                number: 1214
            },
            {
                name: "Onida",
                number: 1214
            }
        ]
    },
    {
        filter: "Price",
        products: [{
                name: "Rs.10,000 to Rs.14,999",
                number: 71723
            },
            {
                name: "Rs.15,000 to Rs.19,999",
                number: 3804
            },
            {
                name: "Rs.20,000 to Rs.24,999",
                number: 387
            },
            {
                name: "Rs.25,000 above",
                number: 28
            }
        ]
    }
];


function createFiltersComponent(filters) {
    for (let i = 0; i < filters.length; i++) {
        //console.log(filters[i]);
        let {
            filter,
            products
        } = filters[i];
        let filterHeadingEl = document.createElement("h1");
        filterHeadingEl.textContent = filter;
        filterHeadingEl.classList.add("sub-heading");
        filtersContainerEl.appendChild(filterHeadingEl);

        let unorderedListEl = document.createElement("ul");
        unorderedListEl.classList.add("unordered-list");
        filtersContainerEl.appendChild(unorderedListEl);

        //console.log(filter, products);
        for (let product of products) {
            let listItemEl = document.createElement("li");
            unorderedListEl.appendChild(listItemEl);

            let checkboxEl = document.createElement("input");
            checkboxEl.type = "checkbox";
            checkboxEl.id = product.name;
            listItemEl.appendChild(checkboxEl);

            let labelEl = document.createElement("label");
            labelEl.htmlFor = checkboxEl.id;
            labelEl.textContent = product.name;
            labelEl.classList.add("label-text");
            listItemEl.appendChild(labelEl);
            //console.log("Print" + product.number);
        }
    }
}

createFiltersComponent(filters);